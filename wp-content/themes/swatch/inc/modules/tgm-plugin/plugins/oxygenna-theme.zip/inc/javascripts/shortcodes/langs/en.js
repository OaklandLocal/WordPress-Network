tinyMCE.addI18n("en.shortcode",{
    desc:"Theme Shortcodes"
});