jQuery(document).ready(function($) {
    // create jquery ui radio buttons
    $('.ui-radio').buttonset();
});